module Main where

import P4b (run)

main :: IO ()
main = do
    input <- readFile "inputs/input4"
    let result = run input
    print result
